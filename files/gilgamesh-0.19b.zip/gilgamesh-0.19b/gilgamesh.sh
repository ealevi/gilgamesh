#!/bin/bash
java -Duser.country=US -Duser.language=en -jar gilgamesh.jar

